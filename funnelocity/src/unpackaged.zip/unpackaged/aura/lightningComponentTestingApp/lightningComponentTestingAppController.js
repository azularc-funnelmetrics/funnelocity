({
   showAlert : function(component, event, helper) {
     alert('Test Alert');
    }
})